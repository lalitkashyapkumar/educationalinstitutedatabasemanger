
public class NewClass {
    public static void main( String aar[])
    {
        System.out.print("hello");
    }
}
