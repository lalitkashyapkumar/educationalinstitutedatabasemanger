-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 06, 2018 at 08:02 AM
-- Server version: 5.5.25-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `date` varchar(20) NOT NULL,
  `roll_no` varchar(20) NOT NULL,
  `attendance` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`date`, `roll_no`, `attendance`) VALUES
('30/04/2018', '150070800011', 0),
('30/04/2018', '150070800017', 1),
('30/04/2018', '150070800023', 0),
('30/04/2018', '150070800026', 1),
('30/04/2018', '150070800045', 0);

-- --------------------------------------------------------

--
-- Table structure for table `datesheet`
--

CREATE TABLE IF NOT EXISTS `datesheet` (
  `date` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `syllabus` varchar(220) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datesheet`
--

INSERT INTO `datesheet` (`date`, `time`, `subject`, `syllabus`) VALUES
('', '', '', ''),
('22/05/2018', '9:00AM', 'NS', 'unit 1, 2, 3');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `name` varchar(30) NOT NULL,
  `date` varchar(20) NOT NULL,
  `feedback` varchar(550) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `date`, `feedback`) VALUES
('Lalit', '6/05/2018', 'hello my name is lalit kumar ');

-- --------------------------------------------------------

--
-- Table structure for table `library`
--

CREATE TABLE IF NOT EXISTS `library` (
  `roll_no` int(15) NOT NULL,
  `name` varchar(30) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `name_of_book` varchar(30) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library`
--

INSERT INTO `library` (`roll_no`, `name`, `branch`, `name_of_book`, `date`) VALUES
(23, 'Kamesh', 'Computer Engg', 'ns', '12/01/2018');

-- --------------------------------------------------------

--
-- Table structure for table `sessionalmarks`
--

CREATE TABLE IF NOT EXISTS `sessionalmarks` (
  `roll_no` varchar(20) NOT NULL,
  `NS` int(11) NOT NULL,
  `PIJ` int(11) NOT NULL,
  `EDM` int(11) NOT NULL,
  `DC` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessionalmarks`
--

INSERT INTO `sessionalmarks` (`roll_no`, `NS`, `PIJ`, `EDM`, `DC`) VALUES
('150070800011', 20, 23, 25, 24),
('150070800017', 25, 25, 25, 25);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `roll_no` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `address` varchar(90) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`roll_no`, `name`, `branch`, `dob`, `address`, `contact`, `email`, `gender`) VALUES
(26, 'Lalit', 'computer Engg.', '12/1/1999', 'Bhiwadi', '123456', 'terrace@gmail.com', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `teacher_id` int(15) NOT NULL,
  `name` varchar(30) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `address` varchar(90) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `name`, `branch`, `dob`, `address`, `contact`, `email`, `subject`) VALUES
(7, '?', '?', '?', '?', '?', '?', '?');

-- --------------------------------------------------------

--
-- Table structure for table `teachingplan`
--

CREATE TABLE IF NOT EXISTS `teachingplan` (
  `subject` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `teaching_plan` varchar(550) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE IF NOT EXISTS `timetable` (
  `day` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `room_no` varchar(20) NOT NULL,
  `teacher_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`day`, `time`, `subject`, `room_no`, `teacher_name`) VALUES
('Monday', '9:00 AM', 'NS', 'D-324', 'Pooja Saharan');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
